package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TopMenu {
	WebDriver driver;
	
	By sejourMenu = By.cssSelector("ul#aut-header-menu>#qa-megamenu-stay>a");
	By bienEtreMenu = By.cssSelector("ul#aut-header-menu#qa-megamenu-wellness>a");
	By gastronomieMenu = By.cssSelector("ul#aut-header-menu>#qa-megamenu-food>a");
	By adventureMenu = By.cssSelector("ul#aut-header-menu>#qa-megamenu-sport>a");
	By multiThemesMenu = By.cssSelector("ul#aut-header-menu>#qa-megamenu-mtt>a");
	By ideesCadeaux = By.cssSelector(".menu.nav-orange.show-for-large-up.nav-left>a");
	
	public TopMenu(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement getMainMenuItem(String mainMenuName) {
		switch(mainMenuName){
		case "sejour" : return driver.findElement(sejourMenu);
		case "bien-Etre" : return driver.findElement(bienEtreMenu);
		case "gastronomie" : return driver.findElement(gastronomieMenu);
		case "Sport & aventure" : return driver.findElement(adventureMenu);
		case "multi-themes" : return driver.findElement(multiThemesMenu);
		case "idees-cadeaux" : return driver.findElement(ideesCadeaux);
		
		default: return driver.findElement(sejourMenu);	
		}
	}
}
