package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
	WebDriver driver;
	
	public By popularProductsSectionHeader = By.cssSelector("section.popular-products.qa-popular-products.widget--d>h2");
	public By searchResults = By.cssSelector("ul.autocomplete-results.has-results>li");
	By searchbox = By.cssSelector("form#search input");

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement getPopularProductsSectionHeader() {
		return driver.findElement(popularProductsSectionHeader);
	}
	
	public WebElement getsearchBox() {
		return driver.findElement(searchbox);
	}
	
	public List<WebElement> getSearchResults() {
		return driver.findElements(searchResults);
	}
	
	public WebElement getFirstSearchResult() {
		return driver.findElement(searchResults);
	}
}
