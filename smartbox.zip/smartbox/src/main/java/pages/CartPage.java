package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CartPage {
	WebDriver driver;
	
	public By votrePanierHeader = By.cssSelector("h3[class^='cart-header__title']");
	public By cartRemoveConfirmOverlay = By.id("cart-remove-confirm");
	By retirerCesArticlesbutton = By.className("cart-remove-confirm__accept");
	
	public CartPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement getvotrePanierHeader() {
		return driver.findElement(votrePanierHeader);
	}
	
	public WebElement getRemoveButton(int rowId) {
		return driver.findElement(By.cssSelector("div#cart-items>div:nth-of-type("+rowId+") a.item__box-qty__remove.button.no-arrow"));
	}
	
	public WebElement getcartRemoveConfirmOverlay() {
		return driver.findElement(cartRemoveConfirmOverlay);
	}
	
	public WebElement getretirerCesArticlesbutton() {
		return driver.findElement(retirerCesArticlesbutton);
	}
}
