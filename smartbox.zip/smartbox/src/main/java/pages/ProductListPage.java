package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ProductListPage {
	WebDriver driver;
	By filtetHeader = By.xpath("//h2[text()='Filtres']");
	public By filterBlocks = By.cssSelector("section.filters-block");
	
	public ProductListPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement getProductLink(int index) {
		return driver.findElement(By.cssSelector("section#ac-cloudSearchResults a[data-position='"+index+"']"));
	}
	
	public WebElement getFilterHeader() {
		return driver.findElement(filtetHeader);
	}
	
	public List<WebElement> getFilterSections() {
		return driver.findElements(filtetHeader);
	}
}
