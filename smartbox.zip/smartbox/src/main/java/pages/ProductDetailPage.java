package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ProductDetailPage {
WebDriver driver;
	
	By ajouterAuPanierButton = By.cssSelector("span.text-left.text-normal.add-to-cart__text>span");
	By productReviewLink = By.cssSelector("a.product-info__review-link");
	public By addToCartOverlay = By.id("addtocart-confirmation");
	public By continuerMesAchatsButton = By.cssSelector("div.columns.small-12.continue-shopping-buttons.no-padding>a:nth-of-type(1)");
	public By voirLePanierButton = By.cssSelector("div.columns.small-12.continue-shopping-buttons.no-padding>a:nth-of-type(2)");
	public By productName = By.id("product-info__title");
	
	public ProductDetailPage(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement getAjouterAuPanierButton() {
		return driver.findElement(ajouterAuPanierButton);
	}
	
	public WebElement getAddToCartOverlay() {
		return driver.findElement(addToCartOverlay);
	}
	
	public WebElement getContinuerMesAchatsButton() {
		return driver.findElement(continuerMesAchatsButton);
	}
	
	public WebElement getvoirLePanierButton() {
		return driver.findElement(voirLePanierButton);
	}
	
	public WebElement getProductName() {
		return driver.findElement(productName);
	}
	
	public WebElement getProductReviewLink() {
		return driver.findElement(productReviewLink);
	}
}
