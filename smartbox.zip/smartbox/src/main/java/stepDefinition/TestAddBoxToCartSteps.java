package stepDefinition;
 
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.CartPage;
import pages.HomePage;
import pages.ProductDetailPage;
import pages.ProductListPage;
import pages.TopMenu;
import utilities.ConfigFileReader;
import utilities.Utils;
 
public class TestAddBoxToCartSteps {
	private static WebDriver driver;
	private static ConfigFileReader configFileReader;
	
	TopMenu topMenu;
	ProductListPage productListPage;
	ProductDetailPage productDetailPage;
	CartPage cartPage;
	HomePage homePage;
	
	By acceptCookies = By.cssSelector("a.optanon-allow-all.accept-cookies-button");
	
	private static String productName = null;

	@Before
    public void setup() {
		// setup Chrome driver
		WebDriverManager.chromedriver().setup();	
    	driver = new ChromeDriver();
    	
    	configFileReader= new ConfigFileReader();
            
        driver.get(configFileReader.getApplicationUrl()); 
        driver.manage().window().maximize();
        driver.findElement(acceptCookies).click();
        
        // instantiate page objects
        topMenu = new TopMenu(driver);
        productListPage = new ProductListPage(driver);
        productDetailPage = new ProductDetailPage(driver);
        cartPage = new CartPage(driver);
        homePage = new HomePage(driver);	
    }
	
	@After
    public void tearDown() {
		driver.close();
    }

	@When("^user adds product to cart1$")
	public void user_adds_product_to_cart1()throws Throwable{
		productName = addProductToCart("gastronomie"); 
	}

	@Then("^add to cart overlay is displayed$")
	public void add_to_cart_overlay_is_displayed() throws Throwable {
		assertTrue(productDetailPage.getAddToCartOverlay().isDisplayed());
	}

	@Then("^options- CONTINUER MES ACHATS and VOIR LE PANIER should be displayed on overlay$")
	public void options_CONTINUER_MES_ACHATS_and_VOIR_LE_PANIER_should_be_displayed_on_overlay() throws Throwable {
		assertTrue(productDetailPage.getContinuerMesAchatsButton().isDisplayed());
    	assertEquals(productDetailPage.getContinuerMesAchatsButton().getText(), "CONTINUER MES ACHATS");
    	assertTrue(productDetailPage.getvoirLePanierButton().isDisplayed());
    	assertEquals(productDetailPage.getvoirLePanierButton().getText(), "VOIR LE PANIER");
	}

	@Given("^user adds product to cart2$")
	public void user_adds_product_to_cart2() throws Throwable{
		productName = addProductToCart("gastronomie"); 	
	}

	@When("^user clicks on see cart\\(VOIR LE PANIER\\) button$")
	public void user_clicks_on_see_cart_VOIR_LE_PANIER_button() throws Throwable{
		Utils.javascriptClick(driver, productDetailPage.getvoirLePanierButton());
    	Utils.explicitWait(driver, cartPage.votrePanierHeader);
	}

	@Then("^product added appears on cart page$")
	public void product_added_appears_on_cart_page() throws Throwable{
		assertTrue(driver.getPageSource().contains(productName));	
	}
	
	@Given("^user adds product to cart3$")
	public void user_adds_product_to_cart3() throws Throwable{
		productName = addProductToCart("gastronomie"); 	
	}

	@Given("^clicks on voir le panier button$")
	public void clicks_on_voir_le_panier_button() throws Throwable {
		Utils.javascriptClick(driver, productDetailPage.getvoirLePanierButton());
    	Utils.explicitWait(driver, cartPage.votrePanierHeader);
	}

	@When("^user clicks on Remove button$")
	public void user_clicks_on_Remove_button() throws Throwable {
		Utils.javascriptClick(driver, cartPage.getRemoveButton(1));   	
    	Utils.explicitWait(driver, cartPage.cartRemoveConfirmOverlay);
	}

	@Then("^remove Confirm overlay is displayed$")
	public void remove_Confirm_overlay_is_displayed() throws Throwable {
		assertTrue(cartPage.getcartRemoveConfirmOverlay().isDisplayed());  	
    	cartPage.getretirerCesArticlesbutton().click();
	}

	@Then("^clicking on accept remove navigates to home page$")
	public void clicking_on_accept_remove_navigates_to_home_page() throws Throwable {
		Utils.explicitWait(driver, homePage.popularProductsSectionHeader);
    	String currentUrl = driver.getCurrentUrl();
    	assertEquals(configFileReader.getApplicationUrl(), currentUrl); 	
	}
	
	public String addProductToCart(String mainMenuItem) {
    	WebElement element = topMenu.getMainMenuItem(mainMenuItem);
    	Utils.javascriptClick(driver, element);
    	Utils.explicitWait(driver, By.cssSelector("h1.description-block__title"));
    	productListPage.getProductLink(1).click();
    	
    	String productName = productDetailPage.getProductName().getText();
    	
    	productDetailPage.getAjouterAuPanierButton().click();
    	Utils.explicitWait(driver, productDetailPage.addToCartOverlay);  	
    	
    	return productName;
    }


}
