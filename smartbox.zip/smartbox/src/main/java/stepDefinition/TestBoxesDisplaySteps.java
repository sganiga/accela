package stepDefinition;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.CartPage;
import pages.HomePage;
import pages.ProductDetailPage;
import pages.ProductListPage;
import pages.TopMenu;
import utilities.ConfigFileReader;
import utilities.Utils;

public class TestBoxesDisplaySteps {
	private WebDriver driver;
	private static ConfigFileReader configFileReader;
	
	TopMenu topMenu;
	ProductListPage productListPage;
	ProductDetailPage productDetailPage;
	CartPage cartPage;
	HomePage homePage;
	
	By acceptCookies = By.cssSelector("a.optanon-allow-all.accept-cookies-button");

	@Before
    public void setup() {
		// setup Chrome driver
		WebDriverManager.chromedriver().setup();	
    	driver = new ChromeDriver();
    	
    	configFileReader= new ConfigFileReader();
            
        driver.get(configFileReader.getApplicationUrl()); 
        driver.manage().window().maximize();
        driver.findElement(acceptCookies).click();
        
        // instantiate page objects
        topMenu = new TopMenu(driver);
        productListPage = new ProductListPage(driver);
        productDetailPage = new ProductDetailPage(driver);
        cartPage = new CartPage(driver);
        homePage = new HomePage(driver);	
    }
	
	@After
    public void tearDown() {
		driver.close();
    }

	@When("^Customer types in any search term$")
	public void Customer_types_in_any_search_term() throws Throwable {
		homePage.getsearchBox().sendKeys("tabl");
    	Utils.explicitWait(driver, homePage.searchResults);
	}

	@Then("^suggestions are displayed below search box$")
	public void suggestions_are_displayed_below_search_box() throws Throwable {
		// assert that more than one search result is returned when user types any common product search
		List<WebElement> results = homePage.getSearchResults();	
    	assertTrue(results.size()>0);
	}

	@When("^Go to any category page$")
	public void Go_to_any_category_page() throws Throwable {
		WebElement element = topMenu.getMainMenuItem("Sport & aventure");
    	Utils.javascriptClick(driver, element);
	}

	@Then("^filter options are displayed on the left hand side$")
	public void filter_options_are_displayed_on_the_left_hand_side() throws Throwable {
		assertTrue(productListPage.getFilterHeader().isDisplayed());
    	
		// more than one filter section should be displayed on product list page
    	List<WebElement> results = productListPage.getFilterSections();  	
    	assertTrue(results.size()>0);
	}

	@When("^Go to any Product detail page$")
	public void Go_to_any_Product_detail_page() throws Throwable {
		WebElement element = topMenu.getMainMenuItem("Sport & aventure");
    	Utils.javascriptClick(driver, element);
    	Utils.explicitWait(driver, By.cssSelector("h1.description-block__title"));
    	productListPage.getProductLink(1).click();
	}

	@Then("^Link to the review section should be displayed$")
	public void Link_to_the_review_section_should_be_displayed() throws Throwable {
		// product review link should be displayed and clicking on that leads to in-page link to the reviews section
		assertTrue(productDetailPage.getProductReviewLink().isDisplayed());     
        assertTrue(productDetailPage.getProductReviewLink().getAttribute("href").contains("#reviews"));
	}


}
