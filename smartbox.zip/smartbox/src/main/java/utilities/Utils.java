package utilities;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Utils {
	
	// JavaScript click in case webDriver click does not work
	public static void javascriptClick(WebDriver driver, WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor)driver;
    	executor.executeScript("arguments[0].click();", element);
	}
	
	public static void javascriptScrollIntoView(WebDriver driver, WebElement element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	public static void explicitWait(WebDriver driver, By elementLocator) {
		ConfigFileReader configFileReader= new ConfigFileReader();
		
		WebDriverWait wait = new WebDriverWait(driver, configFileReader.getWaitTimeOut());
    	wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
	}

}
