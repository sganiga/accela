package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.CartPage;
import pages.HomePage;
import pages.ProductDetailPage;
import pages.ProductListPage;
import pages.TopMenu;
import utilities.ConfigFileReader;
import utilities.Utils;

public class TestAddBoxToCart {
	private static WebDriver driver;
	private static ConfigFileReader configFileReader;
	TopMenu topMenu;
	ProductListPage productListPage;
	ProductDetailPage productDetailPage;
	CartPage cartPage;
	HomePage homePage;
	
	By acceptCookies = By.cssSelector("a.optanon-allow-all.accept-cookies-button");
	
	@BeforeClass
    public static void setupClass() {
		WebDriverManager.chromedriver().setup();	

    }

    @Before
    public void setup() {
    	driver = new ChromeDriver();
    	configFileReader= new ConfigFileReader();
            
        driver.get(configFileReader.getApplicationUrl()); 
        driver.manage().window().maximize();
        driver.findElement(acceptCookies).click();
        
        topMenu = new TopMenu(driver);
        productListPage = new ProductListPage(driver);
        productDetailPage = new ProductDetailPage(driver);
        cartPage = new CartPage(driver);
        homePage = new HomePage(driver);	
    }
    
    @After
    public void tearDown() {
    	driver.close();
    }
    
    @Test
    public void testAddToCartOverlay() {    	
    	String productName = addProductToCart("gastronomie"); 
    	
    	assertTrue(productDetailPage.getAddToCartOverlay().isDisplayed());
    	
    	assertTrue(productDetailPage.getContinuerMesAchatsButton().isDisplayed());
    	assertEquals(productDetailPage.getContinuerMesAchatsButton().getText(), "CONTINUER MES ACHATS");
    	assertTrue(productDetailPage.getvoirLePanierButton().isDisplayed());
    	assertEquals(productDetailPage.getvoirLePanierButton().getText(), "VOIR LE PANIER");
    }
    
    @Test
    public void testProductAddedToCart() { 
    	String productName = addProductToCart("gastronomie"); 	
    	
    	Utils.javascriptClick(driver, productDetailPage.getvoirLePanierButton());
    	Utils.explicitWait(driver, cartPage.votrePanierHeader);
    	
    	assertTrue(driver.getPageSource().contains(productName));	
    }
    
    @Test
    public void testProductRemovedFromCartContainingSingleItem() { 
    	String productName = addProductToCart("gastronomie");
    	
    	Utils.javascriptClick(driver, productDetailPage.getvoirLePanierButton());
    	Utils.explicitWait(driver, cartPage.votrePanierHeader);
    	
    	Utils.javascriptClick(driver, cartPage.getRemoveButton(1));   	
    	Utils.explicitWait(driver, cartPage.cartRemoveConfirmOverlay);
    	
    	assertTrue(cartPage.getcartRemoveConfirmOverlay().isDisplayed());
    	
    	cartPage.getretirerCesArticlesbutton().click();
    	
    	Utils.explicitWait(driver, homePage.popularProductsSectionHeader);
    	String currentUrl = driver.getCurrentUrl();
    	assertEquals(configFileReader.getApplicationUrl(), currentUrl); 	
    }
    
    public String addProductToCart(String mainMenuItem) {
    	WebElement element = topMenu.getMainMenuItem(mainMenuItem);
    	Utils.javascriptClick(driver, element);
    	Utils.explicitWait(driver, By.cssSelector("h1.description-block__title"));
    	productListPage.getProductLink(1).click();
    	
    	String productName = productDetailPage.getProductName().getText();
    	
    	productDetailPage.getAjouterAuPanierButton().click();
    	Utils.explicitWait(driver, productDetailPage.addToCartOverlay);  	
    	
    	return productName;
    }
    
    

}
