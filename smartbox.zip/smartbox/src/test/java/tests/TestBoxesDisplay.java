package tests;

import static org.junit.Assert.assertTrue;

import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.HomePage;
import pages.ProductDetailPage;
import pages.ProductListPage;
import pages.TopMenu;
import utilities.ConfigFileReader;
import utilities.Utils;

public class TestBoxesDisplay {
	private static WebDriver driver;
	private static ConfigFileReader configFileReader;
	
	TopMenu topMenu;
	ProductListPage productListPage;
	ProductDetailPage productDetailPage;
	HomePage homePage;
	
	By acceptCookies = By.cssSelector("a.optanon-allow-all.accept-cookies-button");
	
	@BeforeClass
    public static void setupClass() {
		WebDriverManager.chromedriver().setup();	

    }

    @Before
    public void setup() {
    	driver = new ChromeDriver();
    	
    	configFileReader= new ConfigFileReader();
            
        driver.get(configFileReader.getApplicationUrl()); 
        driver.manage().window().maximize();
        driver.findElement(acceptCookies).click();
        
        topMenu = new TopMenu(driver);
        productListPage = new ProductListPage(driver);
        productDetailPage = new ProductDetailPage(driver);
        homePage = new HomePage(driver);	
    }
    
    @After
    public void tearDown() {
    	driver.close();
    }
    
    @Test
    public void testsuggestionsOnTypingInSearchBox() {    	
    	homePage.getsearchBox().sendKeys("tabl");
    	Utils.explicitWait(driver, homePage.searchResults);
    	
    	List<WebElement> results = homePage.getSearchResults();
    	
    	assertTrue(results.size()>0);
    }
    
    @Test
    public void testFilterOptions() {    	
    	WebElement element = topMenu.getMainMenuItem("Sport & aventure");
    	Utils.javascriptClick(driver, element);
    	
    	assertTrue(productListPage.getFilterHeader().isDisplayed());
    	
    	List<WebElement> results = productListPage.getFilterSections();
    	
    	assertTrue(results.size()>0);
    }
    
    @Test
    public void testProductReviewLink() {    	
    	WebElement element = topMenu.getMainMenuItem("Sport & aventure");
    	Utils.javascriptClick(driver, element);
    	Utils.explicitWait(driver, By.cssSelector("h1.description-block__title"));
    	productListPage.getProductLink(1).click();
    	
    	assertTrue(productDetailPage.getProductReviewLink().isDisplayed());
        
        assertTrue(productDetailPage.getProductReviewLink().getAttribute("href").contains("#reviews"));
       		
    }
    
    
   
    
    

}
